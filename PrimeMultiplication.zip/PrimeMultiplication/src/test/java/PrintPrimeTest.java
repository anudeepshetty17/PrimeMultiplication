
public class PrintPrimeTest {

}
