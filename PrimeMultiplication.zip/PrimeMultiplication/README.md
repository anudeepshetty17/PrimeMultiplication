# PrimeMultiplication
Prime number multiplication table

#System Requirements
Java 1.8 or above

To execute the program download the PrimeMultiplication.jar from target folder and run the below command
$ java -jar PrimeMultiplication.jar 
